# Network Resource Reservation System
## Deliverable 2 — Final Technical Report (Updated with Live Evaluation)

### 1. Objective
Design and evaluate a TCP-based network resource reservation application integrated with an SDN-controlled Mininet network, combining application-level reservation accounting, controller-installed flow rules, and adaptive link bandwidth control.

### 2. Architecture
- **h1 (10.0.0.1):** TCP client and Member 3 test client.
- **h3 (10.0.0.3):** threaded TCP reservation server.
- **s1/s2:** Open vSwitch switches using OpenFlow 1.3.
- **OS-Ken:** controller on TCP 6653; reservation REST endpoint on TCP 8080.
- **s1-eth3:** monitored inter-switch link; Linux HTB applies the dynamic rate cap.
- **10.0.0.254:** host-side veth address used for REST connectivity.

The client sends newline-delimited JSON over TCP. ReservationManager validates and accounts for capacity. On acceptance, the notifier sends an HTTP POST to OS-Ken. The controller installs reservation-specific OpenFlow rules that mark matching IPv4 traffic with DSCP 46. Release and expiry events remove those flows.

### 3. Dynamic SDN behaviour
OS-Ken polls OpenFlow port statistics on s1 port 3 and calculates throughput and utilization relative to the current HTB rate. Sustained high utilization triggers a 5 Mbps step-up; sustained low utilization triggers a step-down. The configured range is 5–20 Mbps. The demonstrated transitions were **5 → 10 → 15 Mbps** under congestion and **15 → 10 → 5 Mbps** after traffic stopped.

HTB is applied using Linux `tc` on `s1-eth3`, not as an OVS QoS object. This is a shared link-level cap, not a per-reservation bandwidth guarantee. DSCP marking alone does not guarantee priority without a corresponding queue/scheduler policy.

### 4. Challenging scenario and robustness
iperf traffic generated congestion. The controller detected sustained utilization near the configured limit and raised the HTB cap, then detected low utilization and returned it to 5 Mbps after traffic stopped. ICMP testing during concurrent traffic showed no packet loss but substantial RTT inflation.

The Member 3 live evaluator was run against the real h3 TCP server. It exercised valid reservation, invalid bandwidth, capacity exhaustion, lease expiry and recovery, and ten concurrent clients. All 16 requests returned application responses; no connection or parsing errors were recorded in this run.

### 5. Performance evaluation

#### 5.1 Throughput comparison
| Mode | Configured policy | Average throughput | Observed duration |
|---|---:|---:|---:|
| Static baseline | Fixed 5 Mbps | 4.60 Mbps | 67.06 s |
| Dynamic controller | Adaptive 5–20 Mbps | 8.16 Mbps | 54.46 s |

The dynamic run was **77.4% higher** in average throughput than the static run. The observed durations differed, so this is an indicative comparison between two runs, not a perfectly controlled paired benchmark or a general guarantee.

#### 5.2 Latency and packet delivery
| Condition | Packets received | Loss | Average RTT | Maximum RTT |
|---|---:|---:|---:|---:|
| Idle ping | 30/30 | 0% | 49.416 ms | 375.153 ms |
| Ping concurrent with iperf | 30/30 | 0% | 1150.967 ms | 2644.617 ms |

The loaded ping run shows severe queueing delay despite zero packet loss. There is no matched static-mode latency run, so the data does not support a claim that dynamic scaling reduced latency.

#### 5.3 Live application evaluation (real TCP server)
The evaluator connected from h1 to the actual server at `10.0.0.3:5000` using newline-delimited JSON. The successful run produced:

| Scenario | Requests | Accepted | Rejected | Mean latency |
|---|---:|---:|---:|---:|
| Valid reservation | 1 | 1 | 0 | 171.96 ms |
| Invalid bandwidth | 1 | 0 | 1 | 50.26 ms |
| Capacity exhaustion | 2 | 1 | 1 | 80.07 ms |
| Expiry and recovery | 2 | 2 | 0 | 119.81 ms |
| 10 concurrent clients | 10 | 6 | 4 | 388.17 ms |

| Live evaluator metric | Observed result |
|---|---:|
| Total TCP requests | 16 |
| Accepted | 10 |
| Rejected | 6 |
| Errors | 0 |
| Average round-trip latency | 281.48 ms |
| Minimum round-trip latency | 50.26 ms |
| Maximum round-trip latency | 468.72 ms |

The valid request was accepted and released successfully. Negative bandwidth was rejected. In the capacity test, a 15 Mbps reservation was accepted while a subsequent 10 Mbps request was rejected because combined demand exceeded the 20 Mbps logical capacity. In the expiry test, the 15 Mbps lease expired; the status query then showed 20 Mbps available and a new 10 Mbps reservation was accepted. Of ten simultaneous 3 Mbps requests, six were accepted (18 Mbps total) and four were rejected, consistent with the 20 Mbps capacity limit.

These are application request round-trip measurements from this specific run, not one-way network latency. The raw per-request measurements are in `member3/live_reservation_results.csv`. Cleanup RELEASED operations are printed by the evaluator but are not counted among the 16 request rows.

### 6. Limitations
1. Static and dynamic throughput runs had different observed durations.
2. Latency-under-load was collected only during dynamic mode.
3. High RTT under load indicates queue buildup; zero packet loss does not mean latency was acceptable.
4. HTB controls the shared inter-switch link; it does not guarantee per-client bandwidth.
5. DSCP 46 marking does not by itself guarantee priority.
6. The live application evaluation is one observed run; latency and concurrency results may vary across runs.

### 7. Reproducibility
Follow the root `README.md`: start OS-Ken, launch the Mininet topology, run `pingall`, start the real TCP server inside h3, and run `member3/evaluation.py` inside h1. The evaluator writes `member3/live_reservation_results.csv`. Then run the iperf congestion test and inspect controller logs and `tc class show dev s1-eth3`.

### 8. Conclusion
The integrated prototype demonstrates TCP reservation handling, REST-based application-to-controller signaling, reservation-specific OpenFlow policy, lease-expiry cleanup, and dynamic HTB rate adaptation based on OpenFlow port statistics. The live evaluator successfully exercised reservation validation, capacity enforcement, expiry recovery, and concurrent clients with zero request errors in this run. The measured dynamic throughput run exceeded the static baseline run, while latency testing exposed substantial queueing under load. The report records demonstrated functionality and limitations without treating the measurements as a fully controlled benchmark.
