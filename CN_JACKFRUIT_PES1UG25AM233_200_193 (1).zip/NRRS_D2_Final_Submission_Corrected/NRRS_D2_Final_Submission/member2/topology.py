"""Four-host, two-switch Mininet topology for the integrated project.

h1 (client) and h2 (traffic generator) connect to s1.
h3 (reservation server) and h4 (traffic generator) connect to s2.
The s1-s2 link is the monitored inter-switch bottleneck.
A dedicated veth pair connects the Ubuntu host (10.0.0.254) to s1 so
Mininet hosts can reach the controller REST API on TCP port 8080.
"""

from mininet.topo import Topo
from mininet.net import Mininet
from mininet.node import RemoteController, OVSSwitch
from mininet.link import TCLink
from mininet.cli import CLI
from mininet.log import setLogLevel, info
import subprocess


class ReservationTopology(Topo):
    def build(self):
        s1 = self.addSwitch("s1", protocols="OpenFlow13", failMode="secure")
        s2 = self.addSwitch("s2", protocols="OpenFlow13", failMode="secure")

        h1 = self.addHost("h1", ip="10.0.0.1/24")
        h2 = self.addHost("h2", ip="10.0.0.2/24")
        h3 = self.addHost("h3", ip="10.0.0.3/24")
        h4 = self.addHost("h4", ip="10.0.0.4/24")

        # Port order is intentional: s1-eth3 is the inter-switch link,
        # matching the dynamic controller's MONITOR_PORT=3 / TC_INTERFACE.
        self.addLink(h1, s1, cls=TCLink, bw=10, delay="2ms")  # s1 port 1
        self.addLink(h2, s1, cls=TCLink, bw=10, delay="2ms")  # s1 port 2
        self.addLink(h3, s2, cls=TCLink, bw=10, delay="2ms")  # s2 port 1
        self.addLink(h4, s2, cls=TCLink, bw=10, delay="2ms")  # s2 port 2
        self.addLink(s1, s2, cls=TCLink, bw=20, delay="5ms")  # s1/s2 port 3


def run_network():
    net = Mininet(
        topo=ReservationTopology(),
        controller=None,
        switch=OVSSwitch,
        link=TCLink,
        autoSetMacs=True,
        build=False,
    )
    net.addController(
        "c0",
        controller=RemoteController,
        ip="127.0.0.1",
        port=6653,
    )

    try:
        info("*** Building integrated four-host/two-switch topology\n")
        net.build()
        net.start()

        # Add a dedicated host-to-OVS veth. It is added only after the
        # three TCLink ports on s1, so the monitored inter-switch link
        # remains s1-eth3 / OpenFlow port 3.
        subprocess.run(["ip", "link", "del", "nrrs-host"],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
        subprocess.run(["ip", "link", "add", "nrrs-host", "type", "veth",
                        "peer", "name", "nrrs-s1"], check=True)
        subprocess.run(["ip", "addr", "add", "10.0.0.254/24", "dev", "nrrs-host"], check=True)
        subprocess.run(["ip", "link", "set", "nrrs-host", "up"], check=True)
        subprocess.run(["ip", "link", "set", "nrrs-s1", "up"], check=True)
        subprocess.run(["ovs-vsctl", "add-port", "s1", "nrrs-s1"], check=True)

        info("*** Ubuntu/REST host address: 10.0.0.254/24 via nrrs-host/nrrs-s1 veth\n")
        info("*** Controller: 127.0.0.1:6653 (OpenFlow 1.3)\n")
        info("*** REST API: http://10.0.0.254:8080/reservation\n")
        info("*** h1=10.0.0.1 client | h3=10.0.0.3 reservation server\n")
        info("*** Run pingall, then use exit to stop the topology\n")
        CLI(net)
    finally:
        info("*** Stopping Mininet\n")
        net.stop()
        subprocess.run(["ip", "link", "del", "nrrs-host"],
                       stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)


if __name__ == "__main__":
    setLogLevel("info")
    run_network()
