"""
Network Resource Reservation System - SDN Controller
OS-Ken / OpenFlow 1.3

Features preserved:
- MAC learning and packet forwarding
- IPv4/ARP learning
- Accepted reservation traffic marked with DSCP 46
- Rejected reservation traffic blocked
- Reservation flow rules removed automatically on expiry

Added:
- OpenFlow port-statistics monitoring on the inter-switch link
- Dynamic HTB bandwidth adaptation using Linux tc
- CSV logging for Member 3 performance evaluation

Run from the member2 directory as root:
    sudo -E "$(which osken-manager)" --verbose sdn_controller
"""

import csv
import json
import os
import queue
import subprocess
import threading
import time
import zlib
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from datetime import datetime

from os_ken.base import app_manager
from os_ken.controller import ofp_event
from os_ken.controller.handler import (
    CONFIG_DISPATCHER,
    MAIN_DISPATCHER,
    DEAD_DISPATCHER,
    set_ev_cls,
)
from os_ken.ofproto import ofproto_v1_3
from os_ken.lib import hub
from os_ken.lib.packet import packet
from os_ken.lib.packet import ethernet
from os_ken.lib.packet import ether_types
from os_ken.lib.packet import ipv4
from os_ken.lib.packet import arp


class ReservationController(app_manager.OSKenApp):

    OFP_VERSIONS = [ofproto_v1_3.OFP_VERSION]

    # ------------------------------------------------
    # DYNAMIC BANDWIDTH SETTINGS
    # Change these only if your topology uses different
    # switch ports, interface names or HTB class IDs.
    # ------------------------------------------------
    MONITOR_DPID = 1
    MONITOR_PORT = 3
    TC_INTERFACE = "s1-eth3"
    TC_PARENT = "5:"
    TC_CLASSID = "5:1"

    INITIAL_RATE_MBPS = 5
    MIN_RATE_MBPS = 5
    MAX_RATE_MBPS = 20
    RATE_STEP_MBPS = 5

    STATS_INTERVAL_SECONDS = 2
    HIGH_UTILIZATION = 0.75
    LOW_UTILIZATION = 0.30
    HIGH_SAMPLES_TO_SCALE_UP = 2
    LOW_SAMPLES_TO_SCALE_DOWN = 4
    RATE_CHANGE_COOLDOWN_SECONDS = 8
    MIN_TRAFFIC_MBPS = 0.5

    METRICS_FILE = "dynamic_congestion_results.csv"
    REST_HOST = "0.0.0.0"
    REST_PORT = 8080
    HOST_IPS = {
        "h1": "10.0.0.1",
        "h2": "10.0.0.2",
        "h3": "10.0.0.3",
        "h4": "10.0.0.4",
    }

    def __init__(self, *args, **kwargs):
        super(ReservationController, self).__init__(*args, **kwargs)

        # Connected OpenFlow switches
        self.datapaths = {}

        # MAC learning table
        self.mac_to_port = {}

        # IP-to-MAC mapping
        self.ip_to_mac = {}

        # Active reservations
        self.reservations = {}

        # Expiry timers
        self.timers = {}

        # Dynamic monitoring state
        self.previous_port_stats = {}
        self.current_rate = self.INITIAL_RATE_MBPS
        self.high_count = 0
        self.low_count = 0
        self.last_rate_change = 0.0
        self.tc_initialized = False

        self.metrics_path = os.path.abspath(self.METRICS_FILE)
        self._initialize_metrics_file()

        self.rest_queue = queue.Queue()
        self.rest_dispatch_thread = hub.spawn(self.rest_dispatch_loop)
        self.monitor_thread = hub.spawn(self.monitor_loop)
        self._start_rest_api()

        self.logger.info("Reservation SDN Controller initialized")
        self.logger.info(
            "[DYNAMIC] Monitoring DPID=%s port=%s (%s)",
            self.MONITOR_DPID,
            self.MONITOR_PORT,
            self.TC_INTERFACE,
        )

    # ================================================
    # REST API FOR MEMBER 1 TCP APPLICATION
    # ================================================

    def _process_rest_payload(self, payload):
        """Run REST-triggered controller changes on the OS-Ken green thread."""
        if not isinstance(payload, dict):
            raise ValueError("Request body must be a JSON object")

        event = str(payload.get("event", "")).upper()
        reservation = payload.get("reservation")
        if not isinstance(reservation, dict):
            raise ValueError("Missing reservation object")

        reservation_id = str(reservation.get("reservation_id", "")).strip()
        if not reservation_id:
            raise ValueError("Missing reservation_id")

        if event == "ACCEPTED":
            source = str(reservation.get("source", "")).strip()
            destination = str(reservation.get("destination", "")).strip()
            src_ip = self.HOST_IPS.get(source, source)
            dst_ip = self.HOST_IPS.get(destination, destination)
            if src_ip not in self.HOST_IPS.values() or dst_ip not in self.HOST_IPS.values():
                raise ValueError("Source/destination must be h1-h4 or a configured host IP")
            if src_ip == dst_ip:
                raise ValueError("Source and destination must differ")

            bandwidth = reservation.get("bandwidth_mbps")
            if isinstance(bandwidth, bool) or not isinstance(bandwidth, (int, float)) or bandwidth <= 0:
                raise ValueError("bandwidth_mbps must be a positive number")

            duration = reservation.get("duration_seconds", 60)
            if isinstance(duration, bool) or not isinstance(duration, (int, float)) or duration <= 0:
                raise ValueError("duration_seconds must be positive")

            result = self.create_reservation(
                reservation_id=reservation_id,
                src_ip=src_ip,
                dst_ip=dst_ip,
                status="accepted",
                duration=float(duration),
            )
            return {
                "status": "OK",
                "action": "installed",
                "reservation_id": reservation_id,
                "bandwidth_mbps": bandwidth,
                "controller_result": result,
            }

        if event in ("RELEASED", "EXPIRED"):
            removed = self.remove_reservation(reservation_id)
            return {
                "status": "OK",
                "action": "removed" if removed else "already_absent",
                "reservation_id": reservation_id,
            }

        raise ValueError("Unsupported event")

    def rest_dispatch_loop(self):
        """Serialize HTTP-triggered changes with OS-Ken's event loop."""
        while True:
            try:
                task = self.rest_queue.get_nowait()
            except queue.Empty:
                hub.sleep(0.05)
                continue

            try:
                task["result"] = (200, self._process_rest_payload(task["payload"]))
            except (ValueError, TypeError, json.JSONDecodeError) as error:
                task["result"] = (400, {"status": "ERROR", "message": str(error)})
            except Exception as error:
                self.logger.exception("REST reservation dispatch failed")
                task["result"] = (500, {"status": "ERROR", "message": str(error)})
            finally:
                task["done"].set()

    def _start_rest_api(self):
        """Expose POST /reservation for the Member 1 SDN notifier."""
        controller = self

        class ReservationRequestHandler(BaseHTTPRequestHandler):
            def do_POST(self):
                if self.path != "/reservation":
                    self._send_json(404, {"status": "ERROR", "message": "Unknown endpoint"})
                    return

                try:
                    length = int(self.headers.get("Content-Length", "0"))
                    if length <= 0 or length > 65536:
                        raise ValueError("Invalid request body length")
                    payload = json.loads(self.rfile.read(length).decode("utf-8"))
                    task = {"payload": payload, "done": threading.Event(), "result": None}
                    controller.rest_queue.put(task)
                    if not task["done"].wait(timeout=2.5):
                        self._send_json(503, {"status": "ERROR", "message": "Controller dispatch timed out"})
                        return
                    status_code, response = task["result"]
                    self._send_json(status_code, response)
                except (ValueError, TypeError, json.JSONDecodeError) as error:
                    self._send_json(400, {"status": "ERROR", "message": str(error)})
                except Exception as error:
                    controller.logger.exception("REST HTTP handler failed")
                    self._send_json(500, {"status": "ERROR", "message": str(error)})

            def _send_json(self, status_code, body):
                encoded = json.dumps(body).encode("utf-8")
                self.send_response(status_code)
                self.send_header("Content-Type", "application/json")
                self.send_header("Content-Length", str(len(encoded)))
                self.end_headers()
                self.wfile.write(encoded)

            def log_message(self, fmt, *args):
                controller.logger.info("[REST] " + fmt, *args)

        try:
            self.rest_server = ThreadingHTTPServer(
                (self.REST_HOST, self.REST_PORT),
                ReservationRequestHandler,
            )
            self.rest_thread = threading.Thread(
                target=self.rest_server.serve_forever,
                name="reservation-rest-api",
                daemon=True,
            )
            self.rest_thread.start()
            self.logger.info(
                "[REST] Reservation API listening on %s:%s",
                self.REST_HOST,
                self.REST_PORT,
            )
        except OSError as error:
            self.rest_server = None
            self.logger.exception("[REST] Could not start API on port %s: %s", self.REST_PORT, error)

    # ================================================
    # DYNAMIC BANDWIDTH MONITORING
    # ================================================

    def _initialize_metrics_file(self):
        """Create the CSV file and header if it does not exist."""
        try:
            if not os.path.exists(self.metrics_path):
                with open(self.metrics_path, "w", newline="") as file:
                    writer = csv.writer(file)
                    writer.writerow([
                        "timestamp",
                        "throughput_mbps",
                        "configured_bandwidth_mbps",
                        "utilization_percent",
                        "action",
                    ])
        except OSError as error:
            self.logger.error(
                "[DYNAMIC] Could not initialize metrics CSV: %s", error
            )

    def log_dynamic_metric(self, throughput, rate, action):
        """Append one measurement to the Member 3 CSV file."""
        utilization = (throughput / rate * 100.0) if rate > 0 else 0.0

        try:
            with open(self.metrics_path, "a", newline="") as file:
                writer = csv.writer(file)
                writer.writerow([
                    datetime.now().isoformat(timespec="seconds"),
                    round(throughput, 3),
                    rate,
                    round(utilization, 2),
                    action,
                ])
        except OSError as error:
            self.logger.error(
                "[DYNAMIC] Could not write metrics CSV: %s", error
            )

    def set_bandwidth(self, rate_mbps):
        """
        Apply the bandwidth limit to the Mininet switch interface.
        The controller must run with root privileges for tc.
        """
        command = [
            "tc", "class", "change",
            "dev", self.TC_INTERFACE,
            "parent", self.TC_PARENT,
            "classid", self.TC_CLASSID,
            "htb",
            "rate", "{}mbit".format(rate_mbps),
            "ceil", "{}mbit".format(rate_mbps),
        ]

        try:
            result = subprocess.run(
                command,
                check=True,
                capture_output=True,
                text=True,
                timeout=4,
            )

            self.current_rate = rate_mbps
            self.last_rate_change = time.monotonic()
            self.logger.info(
                "[DYNAMIC] Bandwidth limit successfully set to %s Mbps",
                rate_mbps,
            )
            return True

        except subprocess.CalledProcessError as error:
            self.logger.error(
                "[DYNAMIC] tc failed. stderr: %s",
                (error.stderr or error.stdout or str(error)).strip(),
            )
            return False

        except Exception as error:
            self.logger.error(
                "[DYNAMIC] Could not change bandwidth: %s", error
            )
            return False

    def monitor_loop(self):
        """Periodically request OpenFlow port statistics."""
        while True:
            datapath = self.datapaths.get(self.MONITOR_DPID)

            if datapath is not None:
                # Mininet creates the interface/qdisc when the topology starts.
                # Retry initialization until tc can successfully change it.
                if not self.tc_initialized:
                    self.tc_initialized = self.set_bandwidth(
                        self.INITIAL_RATE_MBPS
                    )

                parser = datapath.ofproto_parser

                request = parser.OFPPortStatsRequest(
                    datapath,
                    0,
                    self.MONITOR_PORT,
                )

                try:
                    datapath.send_msg(request)
                except Exception as error:
                    self.logger.warning(
                        "[DYNAMIC] Could not request port stats: %s", error
                    )

            hub.sleep(self.STATS_INTERVAL_SECONDS)

    @set_ev_cls(
        ofp_event.EventOFPPortStatsReply,
        MAIN_DISPATCHER,
    )
    def port_stats_reply_handler(self, ev):
        """Monitor throughput and adapt HTB bandwidth safely."""
        datapath = ev.msg.datapath

        if datapath.id != self.MONITOR_DPID:
            return

        now = time.monotonic()

        for stat in ev.msg.body:
            if stat.port_no != self.MONITOR_PORT:
                continue

            key = (datapath.id, stat.port_no)
            previous = self.previous_port_stats.get(key)

            self.previous_port_stats[key] = (stat.tx_bytes, now)

            # First reply establishes the counter baseline.
            if previous is None:
                continue

            previous_bytes, previous_time = previous
            elapsed = now - previous_time

            if elapsed <= 0:
                continue

            # Handle counter resets.
            byte_difference = stat.tx_bytes - previous_bytes

            if byte_difference < 0:
                byte_difference = 0

            throughput_mbps = (
                byte_difference * 8.0 / elapsed / 1_000_000.0
            )

            utilization = (
                throughput_mbps / self.current_rate * 100.0
                if self.current_rate > 0 else 0.0
            )

            self.logger.info(
                "[DYNAMIC] Throughput: %.2f Mbps | Limit: %d Mbps | "
                "Utilization: %.1f%%",
                throughput_mbps,
                self.current_rate,
                utilization,
            )

            action = "no_change"

            current_time = time.monotonic()

            cooldown_finished = (
                current_time - self.last_rate_change
                >= self.RATE_CHANGE_COOLDOWN_SECONDS
            )

            # Ignore idle or extremely low traffic.
            # This prevents bandwidth from being reduced just because
            # there is no active iperf or user traffic.
            if throughput_mbps < self.MIN_TRAFFIC_MBPS:
                self.high_count = 0
                self.low_count = 0
                action = "idle_no_change"

            # Sustained high utilization: increase bandwidth.
            elif utilization >= self.HIGH_UTILIZATION * 100.0:
                self.high_count += 1
                self.low_count = 0

                if (
                    self.high_count >= self.HIGH_SAMPLES_TO_SCALE_UP
                    and self.current_rate < self.MAX_RATE_MBPS
                    and cooldown_finished
                ):
                    new_rate = min(
                        self.current_rate + self.RATE_STEP_MBPS,
                        self.MAX_RATE_MBPS,
                    )

                    if self.set_bandwidth(new_rate):
                        action = "scale_up_to_{}Mbps".format(new_rate)
                        self.high_count = 0

                        self.logger.info(
                            "[DYNAMIC] Sustained congestion detected; "
                            "increased bandwidth to %s Mbps",
                            new_rate,
                        )

            # Sustained low utilization: reduce excess bandwidth.
            elif utilization <= self.LOW_UTILIZATION * 100.0:
                self.low_count += 1
                self.high_count = 0

                if (
                    self.low_count >= self.LOW_SAMPLES_TO_SCALE_DOWN
                    and self.current_rate > self.MIN_RATE_MBPS
                    and cooldown_finished
                ):
                    new_rate = max(
                        self.current_rate - self.RATE_STEP_MBPS,
                        self.MIN_RATE_MBPS,
                    )

                    if self.set_bandwidth(new_rate):
                        action = "scale_down_to_{}Mbps".format(new_rate)
                        self.low_count = 0

                        self.logger.info(
                            "[DYNAMIC] Low utilization sustained; "
                            "reduced bandwidth to %s Mbps",
                            new_rate,
                        )

            else:
                # Moderate utilization: maintain current bandwidth.
                self.high_count = 0
                self.low_count = 0

            self.log_dynamic_metric(
                throughput_mbps,
                self.current_rate,
                action,
            )

    # ================================================
    # FLOW RULE INSTALLATION
    # ================================================

    def add_flow(self, datapath, priority, match, actions=None, cookie=0):
        parser = datapath.ofproto_parser
        ofproto = datapath.ofproto

        if actions is not None:
            instructions = [
                parser.OFPInstructionActions(
                    ofproto.OFPIT_APPLY_ACTIONS,
                    actions,
                )
            ]
        else:
            # No actions means drop matching packets.
            instructions = []

        flow_mod = parser.OFPFlowMod(
            datapath=datapath,
            cookie=cookie,
            priority=priority,
            match=match,
            instructions=instructions,
        )

        datapath.send_msg(flow_mod)

    # ================================================
    # SWITCH CONNECTION MANAGEMENT
    # ================================================

    @set_ev_cls(
        ofp_event.EventOFPStateChange,
        [MAIN_DISPATCHER, DEAD_DISPATCHER],
    )
    def switch_state_change(self, ev):
        datapath = ev.datapath
        dpid = datapath.id

        if ev.state == MAIN_DISPATCHER:
            self.datapaths[dpid] = datapath
            self.mac_to_port.setdefault(dpid, {})

            self.logger.info("Switch %s connected", dpid)

            if dpid == self.MONITOR_DPID:
                self.logger.info(
                    "[DYNAMIC] Monitoring switch connected; "
                    "bandwidth initialization will be attempted"
                )

            self.install_pending_reservations(datapath)

        elif ev.state == DEAD_DISPATCHER:
            self.datapaths.pop(dpid, None)
            self.logger.info("Switch %s disconnected", dpid)

    @set_ev_cls(
        ofp_event.EventOFPSwitchFeatures,
        CONFIG_DISPATCHER,
    )
    def switch_features_handler(self, ev):
        datapath = ev.msg.datapath
        parser = datapath.ofproto_parser
        ofproto = datapath.ofproto

        # Table-miss rule: send unknown packets to the controller.
        match = parser.OFPMatch()

        actions = [
            parser.OFPActionOutput(
                ofproto.OFPP_CONTROLLER,
                ofproto.OFPCML_NO_BUFFER,
            )
        ]

        self.add_flow(
            datapath,
            priority=0,
            match=match,
            actions=actions,
        )

        self.logger.info(
            "Table-miss flow installed on switch %s",
            datapath.id,
        )

    # ================================================
    # PACKET HANDLING AND MAC LEARNING
    # ================================================

    @set_ev_cls(
        ofp_event.EventOFPPacketIn,
        MAIN_DISPATCHER,
    )
    def packet_in_handler(self, ev):
        msg = ev.msg
        datapath = msg.datapath

        dpid = datapath.id
        parser = datapath.ofproto_parser
        ofproto = datapath.ofproto

        in_port = msg.match["in_port"]
        pkt = packet.Packet(msg.data)

        eth = pkt.get_protocol(ethernet.ethernet)

        if eth is None:
            return

        src = eth.src
        dst = eth.dst

        # Ignore LLDP packets.
        if eth.ethertype == ether_types.ETH_TYPE_LLDP:
            return

        # Learn source MAC.
        self.mac_to_port.setdefault(dpid, {})
        self.mac_to_port[dpid][src] = in_port

        # Learn IPv4 address.
        ip_pkt = pkt.get_protocol(ipv4.ipv4)
        if ip_pkt:
            self.ip_to_mac[ip_pkt.src] = src

        # Learn ARP address.
        arp_pkt = pkt.get_protocol(arp.arp)
        if arp_pkt:
            self.ip_to_mac[arp_pkt.src_ip] = src

        # Find destination port.
        out_port = self.mac_to_port[dpid].get(
            dst,
            ofproto.OFPP_FLOOD,
        )

        actions = [parser.OFPActionOutput(out_port)]

        # Install forwarding rule when destination is known.
        if out_port != ofproto.OFPP_FLOOD:
            match = parser.OFPMatch(
                in_port=in_port,
                eth_dst=dst,
            )

            self.add_flow(
                datapath,
                priority=1,
                match=match,
                actions=actions,
            )

        # Forward packet.
        data = None
        if msg.buffer_id == ofproto.OFP_NO_BUFFER:
            data = msg.data

        out = parser.OFPPacketOut(
            datapath=datapath,
            buffer_id=msg.buffer_id,
            in_port=in_port,
            actions=actions,
            data=data,
        )

        datapath.send_msg(out)

        # Attempt to install reservation policies.
        self.install_pending_reservations(datapath)

    # ================================================
    # RESERVATION COOKIE
    # ================================================

    def reservation_cookie(self, reservation_id):
        reservation_id = str(reservation_id)
        return (
            0x5253000000000000
            | zlib.crc32(reservation_id.encode("utf-8"))
        )

    # ================================================
    # INSTALL RESERVATION POLICIES
    # ================================================

    def install_reservation_on_switch(self, reservation, datapath):
        parser = datapath.ofproto_parser

        src_ip = reservation["src_ip"]
        dst_ip = reservation["dst_ip"]
        status = reservation["status"]
        reservation_id = reservation["reservation_id"]

        cookie = self.reservation_cookie(reservation_id)

        # Rejected reservation: block traffic in both directions.
        if status == "rejected":
            directions = [
                (src_ip, dst_ip),
                (dst_ip, src_ip),
            ]

            for source, destination in directions:
                match = parser.OFPMatch(
                    eth_type=ether_types.ETH_TYPE_IP,
                    ipv4_src=source,
                    ipv4_dst=destination,
                )

                self.add_flow(
                    datapath,
                    priority=200,
                    match=match,
                    actions=None,
                    cookie=cookie,
                )

            reservation["installed"].add(datapath.id)

            self.logger.info(
                "Rejected reservation %s blocked on switch %s",
                reservation_id,
                datapath.id,
            )
            return

        # Accepted reservation: prioritize traffic using DSCP 46.
        src_mac = self.ip_to_mac.get(src_ip)
        dst_mac = self.ip_to_mac.get(dst_ip)

        # Wait until both hosts are learned.
        if not src_mac or not dst_mac:
            return

        table = self.mac_to_port.get(datapath.id, {})

        directions = [
            (src_ip, dst_ip, dst_mac),
            (dst_ip, src_ip, src_mac),
        ]

        installed_any = False

        for source, destination, destination_mac in directions:
            out_port = table.get(destination_mac)

            if out_port is None:
                continue

            match = parser.OFPMatch(
                eth_type=ether_types.ETH_TYPE_IP,
                ipv4_src=source,
                ipv4_dst=destination,
            )

            actions = [
                parser.OFPActionSetField(ip_dscp=46),
                parser.OFPActionOutput(out_port),
            ]

            self.add_flow(
                datapath,
                priority=100,
                match=match,
                actions=actions,
                cookie=cookie,
            )

            installed_any = True

        if installed_any:
            reservation["installed"].add(datapath.id)

            self.logger.info(
                "Accepted reservation %s policy installed on switch %s",
                reservation_id,
                datapath.id,
            )

    # ================================================
    # INSTALL PENDING RESERVATIONS
    # ================================================

    def install_pending_reservations(self, datapath):
        for reservation in list(self.reservations.values()):
            if datapath.id in reservation["installed"]:
                continue

            self.install_reservation_on_switch(reservation, datapath)

    # ================================================
    # CREATE RESERVATION
    # ================================================

    def create_reservation(
        self,
        reservation_id,
        src_ip,
        dst_ip,
        status,
        duration,
    ):
        reservation_id = str(reservation_id)
        status = status.lower()

        if status not in ("accepted", "rejected"):
            raise ValueError("Status must be accepted or rejected")

        if duration <= 0:
            raise ValueError("Duration must be positive")

        if reservation_id in self.reservations:
            self.remove_reservation(reservation_id)

        reservation = {
            "reservation_id": reservation_id,
            "src_ip": src_ip,
            "dst_ip": dst_ip,
            "status": status,
            "duration": duration,
            "installed": set(),
        }

        self.reservations[reservation_id] = reservation

        # Install policy on connected switches.
        for datapath in list(self.datapaths.values()):
            self.install_reservation_on_switch(reservation, datapath)

        # Start automatic expiry timer.
        self.timers[reservation_id] = hub.spawn_after(
            duration,
            self.expire_reservation,
            reservation_id,
        )

        self.logger.info(
            "Reservation %s created: %s -> %s, status=%s",
            reservation_id,
            src_ip,
            dst_ip,
            status,
        )

        return {
            "reservation_id": reservation_id,
            "status": status,
            "duration": duration,
            "installed_switches": list(reservation["installed"]),
        }

    # ================================================
    # AUTOMATIC EXPIRY
    # ================================================

    def expire_reservation(self, reservation_id):
        reservation_id = str(reservation_id)
        if reservation_id in self.reservations:
            self.logger.info("Reservation %s expired", reservation_id)
            self.remove_reservation(reservation_id)

    # ================================================
    # REMOVE RESERVATION AND FLOW RULES
    # ================================================

    def remove_reservation(self, reservation_id):
        reservation_id = str(reservation_id)

    # Remove reservation from internal state, if it exists.
        reservation = self.reservations.pop(reservation_id, None)

    # Cancel its timer, if one still exists.
        timer = self.timers.pop(reservation_id, None)
        if timer is not None:
            timer.kill()

    # Always attempt to delete associated flows.
        cookie = self.reservation_cookie(reservation_id)

        deleted_switches = []

        for datapath in list(self.datapaths.values()):
            parser = datapath.ofproto_parser
            ofproto = datapath.ofproto

            delete_flow = parser.OFPFlowMod(
                datapath=datapath,
                command=ofproto.OFPFC_DELETE,
                cookie=cookie,
                cookie_mask=0xffffffffffffffff,
                table_id=ofproto.OFPTT_ALL,
                out_port=ofproto.OFPP_ANY,
                out_group=ofproto.OFPG_ANY,
                match=parser.OFPMatch(),
            )

            datapath.send_msg(delete_flow)
            deleted_switches.append(datapath.id)

        self.logger.info(
        "Reservation %s cleanup completed. "
        "Previously existed: %s. Flow deletion sent to switches: %s",
            reservation_id,
            reservation is not None,
            deleted_switches,
        )

        return reservation is not None
