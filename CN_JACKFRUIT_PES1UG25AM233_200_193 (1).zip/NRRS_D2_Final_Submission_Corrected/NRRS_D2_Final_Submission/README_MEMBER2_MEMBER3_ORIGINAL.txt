NETWORK RESOURCE RESERVATION SYSTEM
Member 2 and Member 3 Deliverables

MEMBER 2: SDN CONTROLLER
- OS-Ken SDN controller using OpenFlow 1.3.
- MAC learning and packet forwarding.
- IPv4 and ARP learning.
- Accepted reservation traffic marked with DSCP 46.
- Rejected reservation traffic blocked.
- Reservation flow installation and automatic expiry.
- Dynamic bandwidth adaptation using OpenFlow port statistics
  and Linux Traffic Control (HTB).

Dynamic bandwidth experiment:
- Initial bandwidth: 5 Mbps.
- Minimum bandwidth: 5 Mbps.
- Maximum bandwidth: 20 Mbps.
- Scale-up and scale-down demonstrated.
- Final evidence is in member3/final_dynamic_scaling_evidence.csv.

Run the controller:
cd member2
source .venv313/bin/activate
sudo env PYTHONPATH="$PWD" .venv313/bin/osken-manager --verbose sdn_controller

Run Mininet in another terminal:
cd member2
sudo python3 topology.py

MEMBER 3: EVALUATION
- TCP reservation evaluation using mock_server.py.
- Static congestion evaluation.
- Throughput analysis and comparison scripts.
- Latency and congestion graphs.
- CSV experiment results.
- Dynamic controller scaling evidence.

Important files:
evaluation.py
mock_server.py
evaluation_topology.py
analyze_congestion.py
compare_results.py
evaluation_summary.txt

EXPERIMENT RESULTS
- Static congestion results: static_congestion_results.csv
- Dynamic controller measurements: dynamic_controller_results.csv
- Final four scaling transitions: final_dynamic_scaling_evidence.csv

NOTES
The dynamic bandwidth implementation uses Linux tc HTB,
controlled by the SDN controller. It is not OpenFlow meter shaping.

This package contains Member 2 and Member 3 deliverables.
Add Member 1's TCP server and integration files separately
when preparing the complete three-member group submission.
