
from mininet.topo import Topo
from mininet.net import Mininet
from mininet.node import OVSSwitch
from mininet.link import TCLink
from mininet.cli import CLI
from mininet.log import setLogLevel


class EvaluationTopology(Topo):

    def build(self):

        h1 = self.addHost('h1', ip='10.0.0.1/24')
        h2 = self.addHost('h2', ip='10.0.0.2/24')
        h3 = self.addHost('h3', ip='10.0.0.3/24')
        h4 = self.addHost('h4', ip='10.0.0.4/24')

        s1 = self.addSwitch(
            's1',
            protocols='OpenFlow13',
            failMode='standalone'
        )

        s2 = self.addSwitch(
            's2',
            protocols='OpenFlow13',
            failMode='standalone'
        )

        self.addLink(h1, s1, cls=TCLink, bw=10, delay='2ms')
        self.addLink(h2, s1, cls=TCLink, bw=10, delay='2ms')

        self.addLink(h3, s2, cls=TCLink, bw=10, delay='2ms')
        self.addLink(h4, s2, cls=TCLink, bw=10, delay='2ms')

        self.addLink(s1, s2, cls=TCLink, bw=20, delay='5ms')


def run_network():

    topo = EvaluationTopology()

    net = Mininet(
        topo=topo,
        controller=None,
        switch=OVSSwitch,
        link=TCLink,
        autoSetMacs=True
    )

    try:
        print("\nStarting independent evaluation network...")
        net.start()

        print("\nNetwork started successfully.")
        CLI(net)

    finally:
        print("\nStopping evaluation network...")
        net.stop()


if __name__ == '__main__':
    setLogLevel('info')
    run_network()
