import pandas as pd
import matplotlib.pyplot as plt

# Load experiment data
df = pd.read_csv("static_congestion_results.csv")

# Calculate statistics
average = df["receiver_mbps"].mean()
minimum = df["receiver_mbps"].min()
maximum = df["receiver_mbps"].max()
std_dev = df["receiver_mbps"].std()

print("\n===== STATIC CONGESTION ANALYSIS =====")
print(f"Number of trials       : {len(df)}")
print(f"Configured bottleneck  : {df['bottleneck_mbps'].iloc[0]} Mbps")
print(f"Average throughput     : {average:.2f} Mbps")
print(f"Minimum throughput     : {minimum:.2f} Mbps")
print(f"Maximum throughput     : {maximum:.2f} Mbps")
print(f"Standard deviation     : {std_dev:.2f} Mbps")

# Generate graph
plt.figure(figsize=(9, 5))

plt.bar(df["trial"], df["receiver_mbps"], label="Measured throughput")
plt.axhline(average, linestyle="--", label=f"Average: {average:.2f} Mbps")
plt.axhline(
    df["bottleneck_mbps"].iloc[0],
    linestyle=":",
    label="Configured bottleneck: 5 Mbps"
)

plt.xlabel("Trial")
plt.ylabel("Receiver Throughput (Mbps)")
plt.title("Static Congestion: Throughput Measurements")
plt.xticks(df["trial"])
plt.ylim(0, 6)
plt.legend()
plt.grid(axis="y", alpha=0.3)
plt.tight_layout()

plt.savefig("static_congestion_graph.png", dpi=300)
print("\nGraph saved as static_congestion_graph.png")

plt.show()
