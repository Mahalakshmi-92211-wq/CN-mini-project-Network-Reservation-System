#!/usr/bin/env python3
"""Member 3 evaluator for the real Member 1 TCP reservation server.

Run inside Mininet h1 while the real server runs in h3 and OS-Ken is active.
The default scenarios and bandwidths match the live run documented in the
D2 report. Results are written beside this script.
"""
import argparse
import csv
import json
import socket
import statistics
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

FIELDS = [
    "scenario", "client_id", "bandwidth_mbps",
    "status", "response_code", "latency_ms"
]
SOURCE = "h1"
DESTINATION = "h3"


def send_request(host, port, request, timeout=10):
    start = time.perf_counter()
    try:
        with socket.create_connection((host, port), timeout=timeout) as sock:
            sock.settimeout(timeout)
            stream = sock.makefile("rwb")
            stream.write((json.dumps(request) + "\n").encode("utf-8"))
            stream.flush()
            line = stream.readline()
            if not line:
                raise ConnectionError("Server closed without a response")
            response = json.loads(line.decode("utf-8"))
    except (OSError, ValueError, json.JSONDecodeError, TimeoutError) as exc:
        response = {"status": "ERROR", "message": str(exc)}
    return response, (time.perf_counter() - start) * 1000


def reserve(client_id, bandwidth, duration=60):
    return {
        "action": "reserve",
        "client_id": client_id,
        "source": SOURCE,
        "destination": DESTINATION,
        "bandwidth_mbps": bandwidth,
        "duration_seconds": duration,
    }


class Evaluator:
    def __init__(self, host, port, timeout):
        self.host = host
        self.port = port
        self.timeout = timeout
        self.rows = []
        self.output = Path(__file__).resolve().parent / "live_reservation_results.csv"

    def request(self, scenario, payload):
        response, latency = send_request(
            self.host, self.port, payload, self.timeout
        )
        row = {
            "scenario": scenario,
            "client_id": payload.get("client_id", ""),
            "bandwidth_mbps": payload.get("bandwidth_mbps", ""),
            "status": response.get("status", "ERROR"),
            "response_code": response.get("code", ""),
            "latency_ms": round(latency, 3),
        }
        self.rows.append(row)
        print(
            f"{scenario:20} | {row['client_id']:18} | "
            f"{row['status']:10} | {latency:.2f} ms"
        )
        return response

    def release(self, client_id, reservation_id):
        payload = {
            "action": "release",
            "client_id": client_id,
            "reservation_id": reservation_id,
        }
        response, latency = send_request(
            self.host, self.port, payload, self.timeout
        )
        print(
            f"  Cleanup {client_id}: "
            f"{response.get('status', 'ERROR')}"
        )
        return response

    def cleanup(self, client_id, response):
        if response.get("status") == "ACCEPTED":
            reservation_id = response.get("reservation_id")
            if reservation_id is not None:
                self.release(client_id, reservation_id)

    def run(self):
        print("\nNETWORK RESOURCE RESERVATION SYSTEM")
        print("LIVE SERVER EVALUATION")
        print("-" * 100)
        print(f"Target server: {self.host}:{self.port}")
        print(f"Logical link: {SOURCE} -> {DESTINATION}")
        print("-" * 100)
        print(f"{'Scenario':20} | {'Client':18} | {'Status':10} | Latency")
        print("-" * 100)

        print("\nTEST 1: Valid reservation")
        cid = "client_1"
        response = self.request("valid_request", reserve(cid, 5))
        self.cleanup(cid, response)

        print("\nTEST 2: Invalid bandwidth")
        self.request("invalid_request", reserve("client_2", -10))

        print("\nTEST 3: Capacity exhaustion")
        cid = "client_3"
        first = self.request("capacity_test", reserve(cid, 15))
        second = self.request("capacity_test", reserve("client_4", 10))
        self.cleanup(cid, first)
        self.cleanup("client_4", second)

        print("\nTEST 4: Reservation expiration")
        self.request(
            "expiry_test", reserve("client_5", 15, duration=2)
        )
        print("\nWaiting 3 seconds for automatic expiration...")
        time.sleep(3)

        status_request = {
            "action": "status",
            "source": SOURCE,
            "destination": DESTINATION,
        }
        status, _ = send_request(
            self.host, self.port, status_request, self.timeout
        )
        print(
            "Capacity after expiry: "
            f"{status.get('available_mbps', 'UNKNOWN')} Mbps available"
        )

        cid = "client_6"
        response = self.request("expiry_test", reserve(cid, 10))
        self.cleanup(cid, response)

        print("\nTEST 5: Concurrent reservation requests")
        print("Sending 10 simultaneous requests...")
        requests = [
            reserve(f"concurrent_{i}", 3) for i in range(1, 11)
        ]
        accepted = []

        with ThreadPoolExecutor(max_workers=10) as pool:
            futures = {
                pool.submit(
                    send_request, self.host, self.port, req, self.timeout
                ): req
                for req in requests
            }
            for future in as_completed(futures):
                req = futures[future]
                response, latency = future.result()
                row = {
                    "scenario": "concurrent_test",
                    "client_id": req["client_id"],
                    "bandwidth_mbps": req["bandwidth_mbps"],
                    "status": response.get("status", "ERROR"),
                    "response_code": response.get("code", ""),
                    "latency_ms": round(latency, 3),
                }
                self.rows.append(row)
                print(
                    f"{row['scenario']:20} | {row['client_id']:18} | "
                    f"{row['status']:10} | {latency:.2f} ms"
                )
                if response.get("status") == "ACCEPTED":
                    accepted.append(
                        (req["client_id"], response["reservation_id"])
                    )

        print("\nCleaning up concurrent reservations...")
        for client_id, reservation_id in accepted:
            self.release(client_id, reservation_id)

        self.write_results()

    def write_results(self):
        with self.output.open("w", newline="", encoding="utf-8") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDS)
            writer.writeheader()
            writer.writerows(self.rows)

        latencies = [row["latency_ms"] for row in self.rows]
        accepted = sum(row["status"] == "ACCEPTED" for row in self.rows)
        rejected = sum(row["status"] == "REJECTED" for row in self.rows)
        errors = sum(row["status"] == "ERROR" for row in self.rows)

        print("\n" + "=" * 48)
        print("EVALUATION SUMMARY")
        print("=" * 48)
        print(f"Total requests:       {len(self.rows)}")
        print(f"Accepted:             {accepted}")
        print(f"Rejected:             {rejected}")
        print(f"Errors:               {errors}")
        if latencies:
            print(f"Average latency:      {statistics.mean(latencies):.2f} ms")
            print(f"Minimum latency:      {min(latencies):.2f} ms")
            print(f"Maximum latency:      {max(latencies):.2f} ms")
        print(f"\nResults saved to: {self.output}")


def main():
    parser = argparse.ArgumentParser(
        description="Evaluate the live Member 1 reservation server"
    )
    parser.add_argument("--host", default="10.0.0.3")
    parser.add_argument("--port", type=int, default=5000)
    parser.add_argument("--timeout", type=float, default=10.0)
    args = parser.parse_args()
    Evaluator(args.host, args.port, args.timeout).run()


if __name__ == "__main__":
    main()
