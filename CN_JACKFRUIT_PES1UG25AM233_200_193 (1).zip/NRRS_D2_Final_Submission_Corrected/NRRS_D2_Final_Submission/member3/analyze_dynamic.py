import csv
import os
from collections import Counter
from datetime import datetime
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

SOURCE = "../member2/dynamic_congestion_results.csv"
OUTPUT = "final_dynamic_scaling_evidence.csv"

required = {
    "scale_up_to_10Mbps",
    "scale_up_to_15Mbps",
    "scale_down_to_10Mbps",
    "scale_down_to_5Mbps",
}

with open(SOURCE, newline="") as f:
    rows = list(csv.DictReader(f))

events = [
    r for r in rows
    if r.get("action", "").strip() in required
]

found = {r["action"].strip() for r in events}
missing = required - found

if missing:
    raise SystemExit(
        "Missing expected scaling events: " + ", ".join(sorted(missing))
        + "\nCheck the source CSV before submitting."
    )

# Keep the final four demonstrated scaling transitions.
events.sort(key=lambda r: r["timestamp"])
with open(OUTPUT, "w", newline="") as f:
    writer = csv.DictWriter(f, fieldnames=[
        "timestamp", "throughput_mbps",
        "configured_bandwidth_mbps",
        "utilization_percent", "action"
    ])
    writer.writeheader()
    writer.writerows(events)

times = [datetime.fromisoformat(r["timestamp"]) for r in events]
throughput = [float(r["throughput_mbps"]) for r in events]
bandwidth = [float(r["configured_bandwidth_mbps"]) for r in events]
actions = [r["action"] for r in events]

fig, ax = plt.subplots(figsize=(10, 5))
ax.plot(times, throughput, marker="o", linewidth=2,
        label="Measured throughput (Mbps)")
ax.step(times, bandwidth, where="post", marker="s",
        linewidth=2, label="Configured bandwidth limit (Mbps)")

for x, y, action in zip(times, bandwidth, actions):
    ax.annotate(action.replace("_", "\n"), (x, y),
                textcoords="offset points", xytext=(0, 10),
                ha="center", fontsize=8)

ax.set_title("Dynamic Bandwidth Scaling Evaluation")
ax.set_xlabel("Time")
ax.set_ylabel("Mbps")
ax.grid(True, alpha=0.3)
ax.legend()
fig.autofmt_xdate()
fig.tight_layout()
fig.savefig("dynamic_scaling_graph.png", dpi=200)
plt.close(fig)

up = sum(a.startswith("scale_up") for a in actions)
down = sum(a.startswith("scale_down") for a in actions)

with open("dynamic_evaluation_summary.txt", "w") as f:
    f.write("DYNAMIC BANDWIDTH SCALING EVALUATION\n")
    f.write("====================================\n")
    f.write(f"Scaling events verified: {len(events)}\n")
    f.write(f"Scale-up events: {up}\n")
    f.write(f"Scale-down events: {down}\n")
    f.write(f"Minimum configured limit: {min(bandwidth):.0f} Mbps\n")
    f.write(f"Maximum configured limit: {max(bandwidth):.0f} Mbps\n")
    f.write(f"Average measured throughput: {sum(throughput)/len(throughput):.3f} Mbps\n")
    f.write("\nVerified transitions:\n")
    for action in actions:
        f.write(f"- {action}\n")
    f.write("\nNote: bandwidth adaptation is applied using Linux tc HTB;\n")
    f.write("OpenFlow port statistics are used to monitor traffic.\n")

print("DYNAMIC EVALUATION COMPLETED")
print(f"Verified events: {len(events)}")
print(f"Scale-up: {up} | Scale-down: {down}")
print("Created:")
print("  final_dynamic_scaling_evidence.csv")
print("  dynamic_scaling_graph.png")
print("  dynamic_evaluation_summary.txt")
