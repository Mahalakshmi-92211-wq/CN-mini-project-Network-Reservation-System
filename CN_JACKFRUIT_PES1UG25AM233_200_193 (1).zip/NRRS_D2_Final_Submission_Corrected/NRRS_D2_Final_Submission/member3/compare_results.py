import matplotlib.pyplot as plt

conditions = ["Baseline\n(preliminary)", "Static Congestion"]
throughput = [7.55, 4.31]

plt.figure(figsize=(8, 5))
bars = plt.bar(conditions, throughput)

plt.ylabel("Receiver Throughput (Mbps)")
plt.title("Network Throughput: Baseline vs Static Congestion")
plt.ylim(0, 10)
plt.grid(axis="y", alpha=0.3)

for bar, value in zip(bars, throughput):
    plt.text(
        bar.get_x() + bar.get_width()/2,
        bar.get_height() + 0.15,
        f"{value:.2f} Mbps",
        ha="center"
    )

plt.tight_layout()
plt.savefig("baseline_vs_congestion.png", dpi=300)
print("Comparison graph saved successfully.")
plt.show()
