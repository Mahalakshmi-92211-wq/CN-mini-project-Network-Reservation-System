# Member 3 — live integration evaluator

The mock-server workflow has been retired. `evaluation.py` sends newline-delimited JSON over TCP to the real Member 1 server in h3 (`10.0.0.3:5000`). It tests valid requests, invalid bandwidth, capacity exhaustion, expiry/recovery, and ten concurrent clients. It writes `live_reservation_results.csv`.

Run from the Mininet CLI after the controller and h3 server are active:

```bash
h1 python3 /absolute/path/to/Network_Resource_Reservation_System_Integrated/member3/evaluation.py
```

There is no mock reservation state or reset endpoint. Accepted test reservations are released after each scenario.
