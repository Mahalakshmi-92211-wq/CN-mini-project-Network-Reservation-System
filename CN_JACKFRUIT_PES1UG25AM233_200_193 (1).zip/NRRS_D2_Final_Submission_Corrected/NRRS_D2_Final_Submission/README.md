# Network Resource Reservation System — Integrated Submission

This package combines the three members' contributions into one runnable project.

## Final architecture

- **h1 (`10.0.0.1`)**: TCP reservation client.
- **h2 (`10.0.0.2`)**: additional client / background traffic source.
- **h3 (`10.0.0.3`)**: TCP reservation server.
- **h4 (`10.0.0.4`)**: additional client / background traffic source.
- **s1 and s2**: Open vSwitch 1.3 switches; the inter-switch link is `s1-eth3`.
- **OS-Ken**: OpenFlow controller on TCP 6653 and REST API on TCP 8080.
- **Ubuntu host-side interface**: `10.0.0.254/24` on `nrrs-host`, connected to OVS `s1` through `nrrs-s1`.

Traffic path for the primary test:

`h1 TCP client -> s1 -> s2 -> h3 TCP reservation server`

When the reservation manager accepts a request, Member 1's notifier sends an HTTP POST to the controller. The controller maps `h1`/`h3` to their Mininet IP addresses and installs reservation-specific OpenFlow rules that mark matching IPv4 packets with DSCP 46. Release and expiry events remove those rules.

The controller separately monitors OpenFlow port statistics on `s1` port 3 and adjusts the HTB rate on `s1-eth3` between 5 and 20 Mbps. This is a **link-level HTB cap**, not a per-reservation bandwidth guarantee. DSCP marking by itself is not a guarantee of priority unless a corresponding QoS queue policy is configured.

## Evaluation evidence and Member 3

Member 3's active evaluator is `member3/evaluation.py`. It connects over TCP from Mininet h1 to the real Member 1 server in h3; it does not use a mock server or reset endpoint. It tests valid requests, invalid bandwidth, capacity exhaustion, lease expiry/recovery, and ten concurrent clients, then writes `member3/live_reservation_results.csv`. The active evaluator uses the exact scenario settings documented in the live report: 5 Mbps valid request, -10 Mbps invalid request, 15+10 Mbps capacity test, 15 Mbps two-second expiry lease followed by a 10 Mbps request, and ten concurrent 3 Mbps requests. It writes `member3/live_reservation_results.csv`. The historical mock server and stale mock-generated results are excluded.

## Requirements

- Ubuntu with Mininet, Open vSwitch, `iperf3`, and `iproute2`/`tc` installed.
- Python environment with OS-Ken installed. The prior working environment in this project was `~/osken-legacy-env`.
- The same project directory must be visible from Mininet hosts (Mininet namespaces share the host filesystem).

## Start from a clean state

Use three ordinary Ubuntu terminals. Do not use `xterm`; the client supports non-interactive command-line operation.

### Terminal 1 — clean Mininet, then start OS-Ken

```bash
sudo mn -c
cd /path/to/Network_Resource_Reservation_System_Integrated/member2
sudo env PYTHONPATH="$PWD" ~/osken-legacy-env/bin/osken-manager --verbose sdn_controller
```

Keep this terminal open. Expected controller messages include the REST API listening on `0.0.0.0:8080`.

### Terminal 2 — start the integrated topology

```bash
cd /path/to/Network_Resource_Reservation_System_Integrated/member2
sudo python3 topology.py
```

At `mininet>` run:

```text
nodes
pingall
sh ovs-vsctl show
sh ovs-ofctl -O OpenFlow13 show s1
sh ovs-ofctl -O OpenFlow13 show s2
```

Expected: four hosts, two switches, controller connections active, and no ping loss.

The topology script creates a veth pair (`nrrs-host` ↔ `nrrs-s1`) and assigns `10.0.0.254/24` to the Ubuntu-side interface. This dedicated switch port is added after the three Mininet links, preserving `s1-eth3` as the monitored inter-switch port. Confirm from the Mininet prompt:

```text
h3 ping -c 3 10.0.0.254
```

### Terminal 3 — optional host-side connectivity check

```bash
curl -i http://127.0.0.1:8080/
```

A 501 response is expected for this GET check; the controller endpoint accepts POST `/reservation`.

## Start the real TCP server inside h3 (no xterm)

At the `mininet>` prompt, use the absolute path to the extracted project. Example:

```text
h3 sh -c 'cd /path/to/Network_Resource_Reservation_System_Integrated/member1 && DEFAULT_CAPACITY_MBPS=20 SDN_CONTROLLER_URL=http://10.0.0.254:8080/reservation python3 -u server.py > /tmp/nrrs_server.log 2>&1 &'
```

Check that it is listening:

```text
h3 ss -ltnp | grep 5000
h3 cat /tmp/nrrs_server.log
```

Keep the server running. The controller must remain running in Terminal 1.

## Send a real reservation from h1

From `mininet>` run this one-shot command (change the path if needed):

```text
h1 python3 /path/to/Network_Resource_Reservation_System_Integrated/member1/client.py --server 10.0.0.3 --action reserve --client-id demo-h1 --source h1 --destination h3 --bandwidth 5 --duration 60
```

Expected application response: `ACCEPTED`, with a reservation ID. The h3 server log should show an `[SDN NOTIFIER] ACCEPTED` response from the controller.

Check reservation flows:

```text
sh ovs-ofctl -O OpenFlow13 dump-flows s1
sh ovs-ofctl -O OpenFlow13 dump-flows s2
```

Look for reservation flows with IPv4 source/destination matches and `set_field:...->ip_dscp` (DSCP 46).

To release, substitute the returned ID:

```text
h1 python3 /path/to/Network_Resource_Reservation_System_Integrated/member1/client.py --server 10.0.0.3 --action release --client-id demo-h1 --reservation-id RESERVATION_ID
```

Then dump the flows again; reservation-cookie flows should be removed. For expiry, make a short reservation (e.g. `--duration 8`) and inspect the server/controller logs and flow table after it expires.

## Run Member 3's real-server evaluation

With the topology running, the OS-Ken controller active, and Member 1's TCP server running in h3, execute from the Mininet prompt:

```text
h1 python3 /absolute/path/to/Network_Resource_Reservation_System_Integrated/member3/evaluation.py
```

The evaluator targets `10.0.0.3:5000` by default and writes `member3/live_reservation_results.csv`. Its defaults reproduce the scenario design used for the reported live run; measured timings and concurrency outcomes can vary on later runs. Do not start a mock server.

## Dynamic congestion experiment

The controller monitors `s1` port 3 and uses `tc` to change the HTB rate on `s1-eth3`. To generate traffic, install/run `iperf3` if needed. For example, in the Mininet CLI:

```text
h3 iperf3 -s -D
h1 iperf3 -c 10.0.0.3 -t 45
```

For more sustained competing traffic, use h2/h4 and repeat with controlled flows. Observe controller logs for throughput, utilization, and `scale_up_to_*` / `scale_down_to_*` actions. The controller writes `dynamic_congestion_results.csv` in its working directory.

## Member 3 evidence

- `member3/static_congestion_results.csv`
- `member3/dynamic_controller_results.csv`
- `member3/final_dynamic_scaling_evidence.csv`
- `member3/*graph.png`
- `member3/evaluation_summary.txt`
- `member3/dynamic_evaluation_summary.txt`

Keep previously measured values labelled as submitted experiment evidence. Do not describe mock-server results as live integrated application measurements.

## Troubleshooting

- **REST connection refused from h3**: ensure OS-Ken is running, port 8080 is free, and `h3 ping -c 3 10.0.0.254` succeeds.
- **No DSCP reservation flows**: check that the client uses `--source h1 --destination h3`, that the h3 server log shows notifier `ACCEPTED`, and that both switches are connected to the controller. The controller needs to learn both endpoint MAC/IP addresses from traffic before installing accepted reservation flows.
- **`tc` errors**: verify that the inter-switch interface is `s1-eth3`, that the topology was started with `TCLink`, and that the controller process has root privileges.
- **Port already in use**: stop old OS-Ken/server processes cleanly before restarting; do not delete package-manager lock files or kill unrelated system services.
- **No GUI/xterm**: not required. Use the non-interactive client command above and launch the h3 server in the background from the Mininet CLI.

## Project folders

- `member1/`: TCP client/server, reservation manager, protocol, notifier and tests.
- `member2/`: OS-Ken controller, integrated Mininet topology and dynamic bandwidth monitoring.
- `member3/`: live TCP evaluator, congestion analysis scripts, measured CSV evidence and graphs.


## Included live evidence
- `member3/live_reservation_results.csv` is the actual 16-request CSV from the successful integrated run documented in the PDF.
- `member3/evaluation.py` is the corrected real-server evaluator. Running it again overwrites that CSV with fresh results.
- The PDF and Markdown report include the same recorded live-run totals: 16 requests, 10 accepted, 6 rejected, 0 errors; mean latency 281.48 ms.
