
import json
import socket
import threading
from concurrent.futures import ThreadPoolExecutor
from collections import Counter

HOST = "127.0.0.1"
PORT = 5000
NUM_CLIENTS = 10
BANDWIDTH_PER_CLIENT = 20

barrier = threading.Barrier(NUM_CLIENTS)


def send_reservation(client_number):
    request = {
        "action": "reserve",
        "client_id": f"concurrent_client_{client_number}",
        "source": "h1",
        "destination": "h2",
        "bandwidth_mbps": BANDWIDTH_PER_CLIENT,
        "duration_seconds": 300
    }

    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:
            client.connect((HOST, PORT))

            # Make all clients begin their requests at approximately
            # the same time.
            barrier.wait(timeout=10)

            client.sendall(
                (json.dumps(request) + "\n").encode("utf-8")
            )

            with client.makefile("r", encoding="utf-8") as reader:
                response = json.loads(reader.readline())

            return response

    except Exception as error:
        return {"status": "ERROR", "message": str(error)}


def main():
    print(f"Starting {NUM_CLIENTS} simultaneous reservation requests...")
    print(f"Each client requests {BANDWIDTH_PER_CLIENT} Mbps.\n")

    with ThreadPoolExecutor(max_workers=NUM_CLIENTS) as executor:
        results = list(
            executor.map(send_reservation, range(1, NUM_CLIENTS + 1))
        )

    counts = Counter(result.get("status") for result in results)

    for index, result in enumerate(results, start=1):
        print(
            f"Client {index}: {result.get('status')} - "
            f"{result.get('message', '')}"
        )

    accepted = counts["ACCEPTED"]
    rejected = counts["REJECTED"]

    print("\n--- Test summary ---")
    print(f"Accepted: {accepted}")
    print(f"Rejected: {rejected}")
    print(f"Errors:   {counts['ERROR']}")

    if accepted == 5 and rejected == 5 and counts["ERROR"] == 0:
        print("PASS: Bandwidth was allocated without over-reservation.")
    else:
        print("CHECK: Unexpected result; inspect the server and responses.")


if __name__ == "__main__":
    main()
