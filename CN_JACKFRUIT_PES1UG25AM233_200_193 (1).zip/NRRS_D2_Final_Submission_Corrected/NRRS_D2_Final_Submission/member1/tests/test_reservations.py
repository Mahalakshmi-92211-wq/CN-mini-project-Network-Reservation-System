
import sys
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from reservation_manager import ReservationManager


class TestReservationManager(unittest.TestCase):
    def setUp(self):
        self.manager = ReservationManager(default_capacity_mbps=100)

    def tearDown(self):
        self.manager.close()

    def reserve(self, bandwidth, client_id="client1", duration=60):
        return self.manager.reserve(
            "h1", "h2", bandwidth, duration, client_id
        )

    def test_accepts_valid_reservation(self):
        result = self.reserve(30)

        self.assertEqual(result["status"], "ACCEPTED")
        self.assertEqual(result["available_mbps"], 70)

    def test_rejects_insufficient_bandwidth(self):
        self.reserve(80)
        result = self.reserve(30, client_id="client2")

        self.assertEqual(result["status"], "REJECTED")
        self.assertEqual(result["available_mbps"], 20)

    def test_releases_bandwidth(self):
        result = self.reserve(40)
        reservation_id = result["reservation_id"]

        release_result = self.manager.release(reservation_id)

        self.assertEqual(release_result["status"], "RELEASED")
        self.assertEqual(
            self.manager.get_status("h1", "h2")["available_mbps"],
            100
        )

    def test_separate_links_have_separate_capacity(self):
        self.reserve(80)

        result = self.manager.reserve(
            "h2", "h3", 80, 60, "client2"
        )

        self.assertEqual(result["status"], "ACCEPTED")

    def test_rejects_invalid_bandwidth(self):
        result = self.reserve(-10)

        self.assertEqual(result["status"], "REJECTED")


if __name__ == "__main__":
    unittest.main(verbosity=2)
