import csv
import json
import socket
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

HOST = "127.0.0.1"
PORT = 5000

results = []


def send_request(request):
    """Send one TCP request and measure round-trip latency."""
    start = time.perf_counter()

    try:
        with socket.create_connection((HOST, PORT), timeout=5) as sock:
            sock.settimeout(5)

            file = sock.makefile("rwb")
            file.write((json.dumps(request) + "\n").encode("utf-8"))
            file.flush()

            response = json.loads(file.readline().decode("utf-8"))

        latency = (time.perf_counter() - start) * 1000
        return response, latency

    except (OSError, json.JSONDecodeError, TimeoutError) as error:
        latency = (time.perf_counter() - start) * 1000
        return {
            "status": "ERROR",
            "message": str(error)
        }, latency


def reserve(client_id, bandwidth, duration=60):
    return {
        "action": "reserve",
        "client_id": client_id,
        "source": "h1",
        "destination": "h2",
        "bandwidth_mbps": bandwidth,
        "duration_seconds": duration
    }


def release(reservation_id, client_id):
    return send_request({
        "action": "release",
        "reservation_id": reservation_id,
        "client_id": client_id
    })[0]


def record(scenario, request, response, latency):
    results.append({
        "scenario": scenario,
        "client_id": request.get("client_id", ""),
        "bandwidth_mbps": request.get("bandwidth_mbps", ""),
        "status": response.get("status", "ERROR"),
        "latency_ms": round(latency, 3)
    })

    print(
        f"{scenario:20} | "
        f"{request.get('client_id', '-'):15} | "
        f"{response.get('status', 'ERROR'):10} | "
        f"{latency:.2f} ms"
    )


def run_one(scenario, request):
    response, latency = send_request(request)
    record(scenario, request, response, latency)
    return response


def cleanup(response, client_id):
    if response.get("status") == "ACCEPTED":
        reservation_id = response.get("reservation_id")

        if reservation_id is not None:
            result = release(reservation_id, client_id)
            print(f"[CLEANUP] Reservation {reservation_id}: "
                  f"{result.get('status')}")


def main():
    print("\nNETWORK RESERVATION SYSTEM: REAL SERVER EVALUATION")
    print("=" * 85)
    print(
        f"{'Scenario':20} | {'Client':15} | "
        f"{'Status':10} | Latency"
    )
    print("-" * 85)

    # Test 1: Valid reservation
    request = reserve("eval_valid", 20)
    response = run_one("valid_request", request)
    cleanup(response, "eval_valid")

    # Test 2: Invalid bandwidth
    request = reserve("eval_invalid", -10)
    run_one("invalid_request", request)

    # Test 3: Capacity exhaustion
    request1 = reserve("eval_capacity_1", 80)
    response1 = run_one("capacity_test", request1)

    request2 = reserve("eval_capacity_2", 30)
    run_one("capacity_test", request2)

    cleanup(response1, "eval_capacity_1")

    # Test 4: Automatic expiry
    request1 = reserve("eval_expiry_1", 80, duration=2)
    run_one("expiry_test", request1)

    print("\nWaiting for reservation to expire...")
    time.sleep(2.5)

    request2 = reserve("eval_expiry_2", 50)
    response2 = run_one("expiry_test", request2)
    cleanup(response2, "eval_expiry_2")

    # Test 5: Concurrent reservations
    print("\nSending 10 concurrent requests...")

    requests = [
        reserve(f"concurrent_{i+1}", 15)
        for i in range(10)
    ]

    accepted_reservations = []

    with ThreadPoolExecutor(max_workers=10) as executor:
        futures = {
            executor.submit(send_request, request): request
            for request in requests
        }

        for future in as_completed(futures):
            request = futures[future]
            response, latency = future.result()

            record("concurrent_test", request, response, latency)

            if response.get("status") == "ACCEPTED":
                accepted_reservations.append(
                    (response["reservation_id"], request["client_id"])
                )

    # Release every successfully accepted concurrent reservation.
    for reservation_id, client_id in accepted_reservations:
        result = release(reservation_id, client_id)
        print(
            f"[CLEANUP] Reservation {reservation_id}: "
            f"{result.get('status')}"
        )

    # Export results.
    with open("results.csv", "w", newline="") as file:
        writer = csv.DictWriter(
            file,
            fieldnames=[
                "scenario",
                "client_id",
                "bandwidth_mbps",
                "status",
                "latency_ms"
            ]
        )

        writer.writeheader()
        writer.writerows(results)

    # Summary.
    latencies = [row["latency_ms"] for row in results]

    accepted = sum(
        row["status"] == "ACCEPTED" for row in results
    )

    rejected = sum(
        row["status"] == "REJECTED" for row in results
    )

    print("\n" + "=" * 45)
    print("EVALUATION SUMMARY")
    print("=" * 45)
    print(f"Total requests:  {len(results)}")
    print(f"Accepted:        {accepted}")
    print(f"Rejected:        {rejected}")
    print(f"Average latency: {sum(latencies) / len(latencies):.3f} ms")
    print(f"Minimum latency: {min(latencies):.3f} ms")
    print(f"Maximum latency: {max(latencies):.3f} ms")
    print("\nResults saved to results.csv")


if __name__ == "__main__":
    main()
