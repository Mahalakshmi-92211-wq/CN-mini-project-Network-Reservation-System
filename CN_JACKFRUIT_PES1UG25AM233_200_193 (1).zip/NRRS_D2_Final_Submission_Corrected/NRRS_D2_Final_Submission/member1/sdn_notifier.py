import json
import threading
from datetime import datetime, timezone
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError


class SDNNotifier:
    def __init__(self, controller_url="http://127.0.0.1:8080/reservation"):
        self.controller_url = controller_url
        self._lock = threading.Lock()

    def notify(self, event, reservation):
        payload = {
            "event": event,
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "reservation": {
                "reservation_id": reservation["reservation_id"],
                "source": reservation["source"],
                "destination": reservation["destination"],
                "bandwidth_mbps": reservation["bandwidth_mbps"],
                "duration_seconds": reservation.get("duration_seconds", 60)
            }
        }

        data = json.dumps(payload).encode("utf-8")

        request = Request(
            self.controller_url,
            data=data,
            headers={"Content-Type": "application/json"},
            method="POST"
        )

        try:
            with self._lock:
                with urlopen(request, timeout=3) as response:
                    result = json.loads(response.read().decode("utf-8"))

            print(f"[SDN NOTIFIER] {event}: {result}")
            return result

        except (URLError, HTTPError, TimeoutError, OSError) as error:
            print(f"[SDN ERROR] Could not notify controller: {error}")
            return None
