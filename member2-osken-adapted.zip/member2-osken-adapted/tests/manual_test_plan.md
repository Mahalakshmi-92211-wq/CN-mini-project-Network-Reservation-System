# Member 2 — Manual Test Plan

## A. Basic topology
1. Start the Ryu controller.
2. Start Mininet with `topology.py`.
3. Run `pingall`.
4. Confirm all three hosts can reach one another before reservation rules are installed.

Expected: all hosts are reachable.

## B. Reservation event
1. POST an ACCEPTED event for reservation ID 1, h1 to h2, 5 Mbps.
2. Inspect Ryu logs and switch meter/flow tables.

Commands from Mininet CLI:
```text
mininet> sh ovs-ofctl -O OpenFlow13 dump-flows s1
mininet> sh ovs-ofctl -O OpenFlow13 meter-stats s1
```

Expected: controller logs an installed reservation; matching flow and meter appear if supported.

## C. Release
1. POST RELEASED for reservation ID 1.
2. Inspect flow and meter tables again.

Expected: the reservation's policy is removed.

## D. Expiry
1. POST EXPIRED for an active reservation.
2. Verify the controller removes the associated policy.

## E. Robustness
Try invalid host names, missing reservation IDs, zero bandwidth and unknown event names.

Expected: REST API returns an error response instead of crashing.

## F. Multiple reservations
Test two different host pairs. Then test two reservations on the same pair.

Expected: identify and document any overlapping-flow behavior. The starter controller is not yet safe for multiple simultaneous reservations on exactly the same pair; resolve this before claiming that case is supported.
