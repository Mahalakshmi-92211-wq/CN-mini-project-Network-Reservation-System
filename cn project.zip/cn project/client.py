
import socket
import json

HOST = "127.0.0.1"
PORT = 5000


def send_request(request):
    """Send one JSON request to the TCP server and return its response."""
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as client:
            client.connect((HOST, PORT))

            message = json.dumps(request) + "\n"
            client.sendall(message.encode("utf-8"))

            with client.makefile("r", encoding="utf-8") as reader:
                line = reader.readline()

                if not line:
                    print("Server closed the connection without a response.")
                    return None

                return json.loads(line)

    except ConnectionRefusedError:
        print("Could not connect. Is server.py running?")
    except (ConnectionError, OSError, json.JSONDecodeError) as error:
        print(f"Communication error: {error}")

    return None


def display_response(response):
    if response is not None:
        print("\nServer response:")
        print(json.dumps(response, indent=4))


def reserve_bandwidth():
    client_id = input("Enter client ID: ").strip()
    source = input("Enter source host (e.g. h1): ").strip()
    destination = input("Enter destination host (e.g. h2): ").strip()

    try:
        bandwidth = float(input("Bandwidth in Mbps: "))
        duration = float(input("Duration in seconds: "))
    except ValueError:
        print("Bandwidth and duration must be numbers.")
        return

    request = {
        "action": "reserve",
        "client_id": client_id,
        "source": source,
        "destination": destination,
        "bandwidth_mbps": bandwidth,
        "duration_seconds": duration
    }

    display_response(send_request(request))


def check_availability():
    source = input("Enter source host (e.g. h1): ").strip()
    destination = input("Enter destination host (e.g. h2): ").strip()

    request = {
        "action": "status",
        "source": source,
        "destination": destination
    }

    display_response(send_request(request))


def release_reservation():
    client_id = input("Enter client ID: ").strip()

    try:
        reservation_id = int(input("Enter reservation ID: "))
    except ValueError:
        print("Reservation ID must be an integer.")
        return

    request = {
        "action": "release",
        "client_id": client_id,
        "reservation_id": reservation_id
    }

    display_response(send_request(request))


def main():
    while True:
        print("\n=== Network Resource Reservation System ===")
        print("1. Reserve bandwidth")
        print("2. Check link availability")
        print("3. Release a reservation")
        print("4. Exit")

        choice = input("Choose an option (1-4): ").strip()

        if choice == "1":
            reserve_bandwidth()
        elif choice == "2":
            check_availability()
        elif choice == "3":
            release_reservation()
        elif choice == "4":
            print("Exiting client.")
            break
        else:
            print("Invalid option. Please choose 1, 2, 3 or 4.")


if __name__ == "__main__":
    main()
